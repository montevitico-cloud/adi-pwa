# Adi 0.5 PWA

## Qué incluye
- PWA instalable
- Interfaz móvil
- Reconocimiento de voz mediante Web Speech API cuando el navegador lo ofrece
- Respuesta por voz con SpeechSynthesis
- Modos General, Profesor, Manager, Gaming y Finanzas
- Memoria local únicamente mediante comandos explícitos
- Limpieza de chat y memoria
- Manifest + service worker
- Preparada para GitHub Pages / HTTPS

## Publicar con GitHub Pages desde el teléfono
1. Crea una cuenta en GitHub si no tienes una.
2. Crea un repositorio nuevo, por ejemplo `adi-pwa`.
3. Sube TODOS los archivos de esta carpeta manteniendo las carpetas `icons` y `.github`.
4. En el repositorio abre Settings > Pages.
5. En Build and deployment selecciona `GitHub Actions` si quieres usar el workflow incluido, o Branch si publicas directamente desde la rama principal.
6. Espera a que termine el despliegue. GitHub Pages publica en una URL `https://TU-USUARIO.github.io/adi-pwa/`.
7. Abre esa URL en Chrome Android. Usa el menú de Chrome para instalar Adi.

## Nota de arquitectura
Esta PWA NO contiene una clave privada ni finge tener un modelo de IA conectado. Para conectar un modelo real hay que añadir un backend seguro; nunca conviene poner una clave secreta de API dentro del JavaScript público de una PWA.
