# Adi Ultimate

PWA de Adi para Android.

## Incluye
- interfaz móvil instalable
- reconocimiento de voz del navegador
- síntesis de voz configurable según las voces disponibles en Android
- modos General, Profesor, Manager, Gaming y Finanzas
- memoria local con autorización explícita
- service worker y manifest con rutas relativas para GitHub Pages

## Importante
Esta edición es el frontend/PWA funcional. No incluye una API key ni un backend de modelo de IA. No se debe colocar una clave privada dentro de este repositorio público. Para un cerebro LLM real, búsqueda web, clima, acciones del teléfono y activación permanente “Hey, Adi” hace falta añadir servicios/backend y, para la activación en segundo plano, una aplicación Android nativa.
